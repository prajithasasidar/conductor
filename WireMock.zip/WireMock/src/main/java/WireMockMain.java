import java.io.IOException;

import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.client.WireMock;
import com.github.tomakehurst.wiremock.http.HttpHeader;

import static com.github.tomakehurst.wiremock.client.WireMock.*;
import static com.github.tomakehurst.wiremock.core.WireMockConfiguration.options;

/**
 * @author Prajitha Sasi
 * @version 1.0
 */
public class WireMockMain {
    private static final String WIREMOCK_HOST = "localhost";
    private static final int WIREMOCK_PORT = 9091;
    public static final String MOCK_FILE_DIRECTORY = "src/test/resources/wire-mock/";

    public static void main(String[] args) throws IOException {
        options().enableBrowserProxying(true);
        WireMockServer wireMockServer = new WireMockServer(options().port(9091));
        wireMockServer.start();
        wireMockServer.resetScenarios();
        WireMock.configureFor(WIREMOCK_HOST, WIREMOCK_PORT);
        // get stay
        setUpWireMockForGet("/props/BPROP/stays/1234", "application/json", 200,
                "stay_1234_response.json");
        // get payment authentication
        setUpWireMockForGet("/props/BPROP/stays/1234/payment", "application/json", 200,
                "stay_1234_response.json");
        // post payment authentication
        setUpWireMockForPost("/props/BPROP/stays/1234/payment", 200, "{\"auth_status\": \"success\"}");
        // get digital key
        setUpWireMockForGet("/props/BPROP/stays/1234/dkey", "application/json", 200,
                "stay_1234_response.json");
        // post digital key
        setUpWireMockForPost("/props/BPROP/stays/1234/dkey", 200, "{\"dkey_status\": \"success\", \"dkey_id\": \"1111-22222-33333-44444\"}");
        // get assigned rooms
        setUpWireMockForGet("/props/BPROP/stays/1234/assignedroom", "application/json", 200,
                        "assigned_rooms_1234.json");

        setUpWireMockForGet("/myproj/1234", "application/json", 200, "myproj.json");
        // auto assign room
        setUpWireMockForPost("/props/BPROP/assignedrooms", 204);
        // update stay status
        setUpWireMockForPut("/props/BPROP/stays/1234", 204);
        // create folio
        setUpWireMockForPost("/props/BPROP/folios", 201);
        setUpWireMockForGet("/props/BPROP/folios/1212", "application/json", 200, "get_folio_50513.json");
        System.out.println("wire mock mappings ------------> " + WireMock.listAllStubMappings().getMappings());

    }

    public static void setUpWireMockForGet(String uri, String contentType, int status,
                                           String bodyFile) {
        stubFor(WireMock.get(urlEqualTo(uri)).willReturn(
                aResponse().withStatus(status).withHeader("Content-Type", contentType)
                        .withBodyFile(bodyFile)));
    }

    public static void setUpWireMockForPut(String uri, int statusCode) {
        stubFor(WireMock.put(urlPathEqualTo(uri)).willReturn(aResponse().withStatus(statusCode)));
    }

    public static void setUpWireMockForPost(String uri, int statusCode, String responseBody) {

        stubFor(WireMock.post(urlPathEqualTo(uri)).willReturn(aResponse().withStatus(statusCode).withBody(responseBody)));
    }

    public static void setUpWireMockForPost(String uri, int statusCode) {

        stubFor(WireMock.post(urlPathEqualTo(uri)).willReturn(aResponse().withStatus(statusCode).withHeader("Location", "1212")));
    }
}
