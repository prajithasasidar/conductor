package com.worker;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.netflix.conductor.client.worker.Worker;
import com.netflix.conductor.common.metadata.tasks.Task;
import com.netflix.conductor.common.metadata.tasks.TaskResult;
import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

import java.io.IOException;

public class MyProjWorker implements Worker {

    private OkHttpClient client = new OkHttpClient();
    private String taskDefName;

    MyProjWorker(String taskDefName) {
        this.taskDefName = taskDefName;
    }

    public String getTaskDefName() {
        return taskDefName;
    }

    public TaskResult execute(Task task) {

        System.out.printf("Executing %s\n", taskDefName);
        System.out.printf("task %s\n", task.getInputData());


        TaskResult result = new TaskResult(task);
        result.setStatus(TaskResult.Status.COMPLETED);

        HttpUrl route = HttpUrl.parse("http://localhost:9091/myproj/1234");
        Request request = new Request.Builder()
                .url(route)
                .get()
                .build();
        try {
            try (Response response = this.client.newCall(request).execute()) {
                if (response.code() == 200) {
                    System.out.println("success");
                    result.getOutputData().put("outputKey1", responseObj(response));
                }
                if (response.code() == 400) {
                    System.out.println("error");
                    return null;
                }
            }
        } catch (IOException e) {
            System.out.println("error" + e.getMessage());
            return null;
        }

        return result;
    }

    public static MyProj responseObj(Response response) throws IOException {
        ObjectMapper mapper = new ObjectMapper();
        MyProj stayResponse = mapper.readValue(response.body().bytes(), MyProj.class);
        System.out.println("MyProj--------> " + stayResponse);
        return stayResponse;
    }
}
